# Javeria Novels — جویریہ کے ناول

Vercel پر لگانے کے مراحل:
1. GitHub پر اپنی repository (javeria-novels) میں ان فائلوں کو Upload کریں۔ index.html کا نام بالکل یہی رہنا چاہیے۔
2. Vercel خود نئی سائٹ لگا دے گا۔
3. Google Search Console میں https://javeria-novels.vercel.app/ شامل کریں اور sitemap.xml جمع کروائیں۔
